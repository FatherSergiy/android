package com.example.shnaiderse;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class SiginIn extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sigin_in);
    }
}